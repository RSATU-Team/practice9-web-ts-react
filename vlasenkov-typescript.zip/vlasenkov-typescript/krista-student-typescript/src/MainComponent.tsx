import React, {useEffect, useState} from 'react';
import Search from "./Search";
import Table from 'react-bootstrap/Table';

// Создание пользовательских компонент
const MyComponent = () => {
    const [counter, setCounter] = useState(0);
    const increaseValue = () => {
        setCounter(counter + 1);
    };

    const decreaseValue = () => {
        setCounter(counter - 1);
    };

    return <div>
        <button onClick={increaseValue}>Inc</button>
        {counter}
        <button onClick={decreaseValue}>Dec</button>
    </div>;
}

interface Man {
    id: number,
    firstName: string,
    lastName: string,
    email: string,
    gender: string,
    ipAddress: string
}

const MainComponent = () => {
    const [searchValue, setSearch] = useState<string>("")
    const [counter, setCounter] = useState(0)
    const [list, setList] = useState<Man[]>([])
    const onChangeSearch = (value: string) => {
        setSearch(value);
    };

    const fetchList = async () => {
        const response = await fetch("http://localhost:3000/");
        const result = await response.json();
        setList(result);
    }

    useEffect(() => {
        fetchList()
    }, [])

    const increaseValue = () => {
        setCounter(counter + 1);
    };

    const decreaseValue = () => {
        setCounter(counter - 1);
    };

    //return <MyComponent></MyComponent>;

    return (
        <div>
            <Search value={searchValue} onChangeHandler={onChangeSearch}/>
            <div>
                Значение из поиска: {searchValue}
            </div>
            <hr/>
            <Table className="table">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">First Name</th>
                    <th scope="col">Last Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Gender</th>
                    <th scope="col">IP address</th>
                </tr>
                </thead>
                <tbody>
                {list.filter((value => value.gender.includes(searchValue))).map(value => <tr key={value.id}>
                    <th>{value.id}</th>
                    <th>{value.firstName}</th>
                    <th>{value.lastName}</th>
                    <th>{value.email}</th>
                    <th>{value.gender}</th>
                    <th>{value.ipAddress}</th>
                </tr>)}
                </tbody>
            </Table>
        </div>
    );
}

export default MainComponent;
